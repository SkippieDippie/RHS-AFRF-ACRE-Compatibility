name 			= "CVO Everything Compats";
author 			= "CVO";

tooltip 		= "CVO Everything Compats";
tooltipOwned 	= "CVO Everything Compats";
overview 		= "This mod aims to make certain mods compatible with mods like ACRE, GreenMag and possibly other.";

actionName 		= "GitHub";
action 			= "https://github.com/SkippieDippie/CVO-Everything-Compats";

hideName 		= 0;
hidePicture 	= 0;

picture 		= "cvo_picture.paa";
logo 			= "cvo_logo.paa";
logoOver 		= "cvo_logo_small.paa";